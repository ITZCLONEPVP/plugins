<?php

namespace Annihilation;

use pocketmine\Plugin\PluginBase;

class Main extends PluginBase {
    
     public function onLoad() {
     $this->getLogger()->info("Plugin Loading");
     }
     public function onEnable(){
     $this->getLogger()->info("Enabled Plugin");
     }
     public function onDisable(){
     $this->getLogger()->info("Plugin Disabled");
     }
    
}