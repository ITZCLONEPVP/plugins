<?php

namespace NexusManager;

use pocketmine\Item\item;
use pocketmine\math\vector3;
use pocketmine\server;

class NexusManager{
    
    public $Blue_Nexus, $Red_Nexus, $Green_Nexus, $Yellow_Nexus;
    
    public $sound;
    
    public $laws;
    
    public $times;
    
    public $show;
    
    public function Setblock{
        $this->setblock()->respawn()->$Times()->item()->item::"end_stone";
        $this->create()->("$times")()->Respawn()->respawn::"75";
    }
}
    }
    
    public function SendMessage_($sender, $server){
        $sender->SendMessage()->getplayer()->getname()->TextFormat Red . ::("[Has Damaged Reds Nexus]");
    
    }
}    