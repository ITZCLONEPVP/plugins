<?php

namespace Acrobat;

use pocketmine\Util\Item;
use pocketmine\event\Listener;

class Main extends PluginBase implements Listener{
    
if($button->("Acrobat"){
     if(!$sender instanceof Player){ 
          $sender->sendMessage("You Selected Kit Acrobat");
     }else{ 
          $sender->getArmour()->addItem(Item::get(
          $sender->getArmour()->addItem(Item::get(
          $sender->getArmour()->addItem(Item::get(301 $args[0]));
          $sender->getArmour()->addItem(Item::get(302 $args[0]));
          $sender->getitem()->hotbar()->addItem(Item::get(269 $args[0]));
          $sender->getitem()->hotbar()->addItem(Item::get(271 $args[0]));
          $sender->getitem()->hotbar()->addItem(Item::get(272 $args[0]));
          $sender->getitem()->hotbar()->addItem(Item::get(
          $sender->getitem()->hotbar()->addItem(Item::get(
     }
}